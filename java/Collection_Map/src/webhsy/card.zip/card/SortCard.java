package webhsy.card;

import java.util.Comparator;

public class SortCard implements Comparator<Card>{

	@Override
	public int compare(Card o1, Card o2) {
		if(o1.getRank() > o2.getRank()) {
			return 1;
		}else if(o1.getRank() == o2.getRank()) {
			o1.getSuit().compareTo(o2.getSuit());
		}else {
			return -1;
		}
		return 0;
	}

}
